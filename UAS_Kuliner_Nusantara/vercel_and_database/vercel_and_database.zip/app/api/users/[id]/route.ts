import { getPrisma, getRawPrisma } from "../../../../backend-scripts/database";
import { NextResponse } from "next/server";
import { requireRole } from "@/backend-scripts/auth-guard";

export async function DELETE(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  const auth = await requireRole(["admin"]);
  if (auth.error) return auth.error;

  try {
    const userId = Number((await params).id);

    if (!Number.isSafeInteger(userId)) {
      return NextResponse.json(
        { error: "ID user tidak valid." },
        { status: 400 },
      );
    }

    if (String(auth.user.user_id) === String(userId)) {
      return NextResponse.json(
        { error: "Admin tidak bisa menghapus akunnya sendiri." },
        { status: 400 },
      );
    }

    const db = getRawPrisma();

    const hapusUser = db.raw.sql`
      DELETE FROM public."User"
      WHERE user_id = ${userId}
      RETURNING user_id
    `
      .returnsRow({ user_id: "pg/numeric@1" })
      .build();

    const rows = await db.query(hapusUser);

    if (rows.length === 0) {
      return NextResponse.json(
        { error: "User tidak ditemukan." },
        { status: 404 },
      );
    }

    const hapusReview = db.raw.sql`
      DELETE FROM public."Review"
      WHERE user_id = ${userId}
      RETURNING review_id
    `
      .returnsRow({ review_id: "pg/numeric@1" })
      .build();
    await db.query(hapusReview);

    const hapusFavorite = db.raw.sql`
      DELETE FROM public."Favorite"
      WHERE user_id = ${userId}
      RETURNING favorite_id
    `
      .returnsRow({ favorite_id: "pg/numeric@1" })
      .build();
    await db.query(hapusFavorite);

    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
