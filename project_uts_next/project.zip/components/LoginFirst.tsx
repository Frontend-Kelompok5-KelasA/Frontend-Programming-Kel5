"use client";

import Image from "next/image";
import Link from "next/link";

export default function LoginFirst() {
    return (
        <main>
            <div id="modal-login-dulu">
                <div className="modal-login-content">
                    <Image className="gambar-logo-login" src="/images/websiteEssentials/logo.png" alt="" width={200} height={200}/>
                    <h3>Harap Login/Register Terlebih Dahulu</h3>
                    <p>Buat akun untuk dapat akses keseluruhan fitur dari website kami.</p>

                    <div className="login-actions">
                        <Link href="/login">
                        <button id="login-button">Login</button></Link>
                        <Link href="/sign-up"><button id="register-button">Register</button></Link>
                    </div>
                </div>
            </div>
        </main>
    );
}