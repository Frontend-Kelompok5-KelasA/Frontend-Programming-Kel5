"use client";

import { useState } from "react";

export default function FavoriteButton() {
    const [isFavorite, setIsFavorite] = useState(false);
    return(
        <button
            onClick={() => setIsFavorite(!isFavorite)}
            className={`favorite-btn ${isFavorite ? "active" : ""}`}
        >
            <svg
                width="30"
                height="32"
                viewBox="0 0 100 120"
                xmlns="http://www.w3.org/2000/svg"
            >
                <path
                    d="M15 5 H85 V115 L50 87 L15 115 Z"
                    fill={isFavorite ? "#ff9b19" : "none"}
                    stroke="#ff9b19"
                    strokeWidth="5"
                    strokeLinejoin="round"
                />
            </svg>

            {isFavorite && (
                <span className="particles">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                </span>
            )}
        </button>
    )
}