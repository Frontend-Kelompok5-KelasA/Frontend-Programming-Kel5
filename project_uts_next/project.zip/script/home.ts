"use client";

declare const bootstrap: any;

async function loadPageConfig(
    refs: any,
    states: {factContent: any, specialContent: any}
){
    const applyConf = (ref: any, comps: Record<string, string|number>) => {
        Object.entries(comps).forEach(([compId, data]: [string, string|number]) => {
            ref[compId] = data;
        })
    };

    const res = await fetch('/api/config/home');

    const { config } = await res.json();
    if(!config)return;

    applyConf(refs.hero.title, config.hero.title);
    applyConf(refs.hero.subtitle, config.hero.subtitle);

    applyConf(refs.facts.title, config.facts.title);
    applyConf(refs.facts.subtitle, config.facts.subtitle);

    let factContent = "";
    config.facts.contents.forEach((data: {
        "id": string,
        "title": Record<string, string|number>,
        "subtitle": Record<string, string|number>,
        "image": Record<string, string|number>
    }) => {
        factContent += `
            <div className="col-12 col-md-6 col-lg-3 ${data.id}">
                <div className="the-facts">
                    <img className="facts-image" 
                            src=${data.image.src} 
                            alt=${data.image.alt} 
                            width={500} 
                            height={500} 
                    />
                    <h2>${data.title.textContent}</h2>
                    <p>${data.subtitle.textContent}</p>
                </div>
            </div>
        `;
    });
    states.factContent(factContent);

    applyConf(refs.special.title, config.special.title);
    applyConf(refs.special.subtitle, config.special.subtitle);

    let specialContent = '';
    config.special.contents.forEach((data: {
        "id": string,
        "title": Record<string, string|number>,
        "subtitle": Record<string, string|number>,
        "image": Record<string, string|number>
    }, i: number) => {
        specialContent += `
            <div className="carousel-item special-content ${i === 0 ? 'active' : ''}">
                <img src=${data.image.src} alt=${data.image.alt} width={2000} height={2000} />
                <div className="carousel-caption">
                    <h2>${data.title.textContent}</h2>
                    <p>${data.subtitle.textContent}</p>
                </div>
            </div>
        `;
    });
    states.specialContent(specialContent);

    applyConf(refs.popular.title, config.popular.title);
    applyConf(refs.popular.subtitle, config.popular.subtitle);

    applyConf(refs.explore.title, config.explore.title);
    applyConf(refs.explore.subtitle, config.explore.subtitle);
    applyConf(refs.explore.button, config.explore.button);
}

export async function onLoad(refs: any, states: {factContent: any, specialContent: any}){
    await loadPageConfig(refs, states);

    const foodList = document.getElementById("food-list");
    const popularList = document.getElementById("popular-list");
    const searchInput = document.getElementById("search-rest");
    let resizeTimer: NodeJS.Timeout;
    window.addEventListener("resize", () => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(bangunCarousel, 150);
    });
    const gambar_def = "migor.png";

    const CARD_WIDTH = 288;
    const CARD_GAP = 24;
    const ROW_PADDING = 32;
    const MAX_PER_SLIDE = 5;
    const JUMLAH_SLIDE = 5;
    let currentUser: any = null;

// 1 item itu 1 restoran (semua lokasi/cabangnya ada di item.location)
    interface GabunganResto {
        key: string,
        name: string,
        desc: string,
        image: string,
        cat: string,
        tag: string,
        status: string,
        official_website: string,
        instagram: string,
        locations: {
            id: string,
            city: string,
            place: string,
            open_hour: string,
            rating: number,
            price: string,
            harga: {
                min: number,
                max: number
            }
        }[]
    }

    let gabunganResto: GabunganResto[] = [];
    let popularCards: HTMLElement[]|Element[] = [];
    let perSlide = 0;

    const filterTerpilih: Record<string, Set<any>> = { tag: new Set(), cat: new Set(), price: new Set() };

// pilihan range harga
    const PRICE_RANGES = [
        { label: "< Rp50.000", min: 0, max: 50000 },
        { label: "Rp50.000 - Rp100.000", min: 50000, max: 100000 },
        { label: "> Rp100.000", min: 100000, max: Infinity }
    ];

// "50.000-75.000" -> { min: 50000, max: 75000 }, kalau kosong -> null
    function parseHarga(str: string) {
        if (!str) return null;
        const angka = str.split("-").map(
            (s: string) => parseInt(s.replace(/\./g, ""), 10)
        );
        if (angka.some(isNaN)) return null;
        return { min: angka[0], max: angka[angka.length - 1] };
    }

    // rata-rata rating dari semua cabang
    function rataRating(resto: Record<string, any>) {
        const r = resto.locations
            .map((l: Record<string, string|number>) => l.rating)
            .filter((x: any) => typeof x === "number"
            );
        if (r.length === 0) return 0;
        return Math.round(
            (r.reduce((a: number, b: number) => a + b, 0) / r.length) * 100
        ) / 100;
    }

// menggabungkan data yang namanya sama jadi 1 card dengan banyak lokasi
    function gabungCabangResto(restos: Record<string, any>[]) {
        const map = new Map();

        restos.forEach((r: Record<string, any>) => {
            const key = r.name.trim().toLowerCase();

            if (!map.has(key)) {
                map.set(key, {
                    key: key,
                    name: r.name.trim(),
                    desc: r.desc,
                    image: r.image,
                    cat: r.cat,
                    tag: r.tag,
                    status: r.status,
                    official_website: r.official_website,
                    instagram: r.instagram,
                    locations: []
                });
            }

            const gabungan = map.get(key);

            // kalau data pertama kosong, pakai yang lain yang terisi
            if (!gabungan.desc && r.desc) gabungan.desc = r.desc;
            if (!gabungan.image && r.image) gabungan.image = r.image;

            gabungan.locations.push({
                id: r.id,
                city: r.city,
                place: r.place,
                open_hour: r.open_hour,
                rating: r.rating,
                price: r.price,
                harga: parseHarga(r.price)
            });
        });

        return [...map.values()];
    }

    function buatTombolFilter(wadah: HTMLElement|null|undefined, teks: string, nilai: string|undefined|number) {
        if(!wadah || nilai == undefined)return;

        const button = document.createElement("button");

        button.className = "filter-option";
        button.textContent = teks;
        button.dataset.value = String(nilai);

        button.addEventListener("click", () => {
            button.classList.toggle("selected");
        });

        wadah.appendChild(button);
    }

    function renderExploreCarousel(restos: Record<string, any>[]) {
        const carousel = document.getElementById("explore-carousel");
        if (!carousel) return;

        const inner = carousel.querySelector(".carousel-inner");

        const gambarUnik = [...new Set(restos.map((r) => r.image).filter(Boolean))];
        if (gambarUnik.length === 0) return; // slide statis di HTML tetap dipakai

        for (let i = gambarUnik.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [gambarUnik[i], gambarUnik[j]] = [gambarUnik[j], gambarUnik[i]];
        }

        const dipilih = gambarUnik.slice(0, 12);

        if(inner){
            inner.innerHTML = dipilih.map((g, i) => `
                <div class="carousel-item ${i === 0 ? "active" : ""}">
                    <img src="/images/restaurantImages/${g}" alt="Kuliner Nusantara" loading="lazy">
                </div>
            `).join("");

            inner.innerHTML = gambarUnik.map((g, i) => `
                <div class="carousel-item ${i === 0 ? "active" : ""}">
                    <img src="/images/restaurantImages/${g}" alt="Kuliner Nusantara" loading="lazy">
                </div>
            `).join("");
        }

        bootstrap.Carousel.getOrCreateInstance(carousel);
    }

    function renderFoodCards(restos: GabunganResto[], target = foodList, tampilRating = false) {
        if(target)target.innerHTML = "";

        // kalau alfabet restoran tidak ada yang sama dengan nama resto, resto tidak ditemukan
        if (target && restos.length === 0) {
            target.innerHTML = '<p class="no-result">Restoran tidak ditemukan.</p>';
            return;
        }

        restos.forEach((resto) => {
            const imageFile = resto.image ? resto.image : gambar_def;
            const firstLoc = resto.locations[0];
            const extra = resto.locations.length - 1;

            const card = document.createElement("div");
            card.className = "card";
            card.style.width = CARD_WIDTH + "px";

            card.innerHTML = `
                <img src="/images/restaurantImages/${imageFile}" class="card-img-top" alt="${resto.name}">
                <div class="card-body">
                    <h5 class="card-title">${resto.name}</h5>
                    <p class="card-text">${resto.desc}</p>
                    <p class="card-loc">📍 ${firstLoc.city || "-"}${extra > 0 ? ` <small>(+${extra} cabang lain)</small>` : ""}</p>
                    <button class="but-card" data-key="${resto.key}">Lihat Detail</button>
                </div>
            `;

            if(target)target.appendChild(card);
        });
    }

    function renderPopular() {
        const populer = gabunganResto
            .map((resto) => ({ ...resto, rataRating: rataRating(resto) }))
            .sort((a, b) => b.rataRating - a.rataRating);

        const temp = document.createElement("div");
        renderFoodCards(populer, temp, true);
        popularCards = [...temp.querySelectorAll(".card")];

        if(popularList && popularCards.length === 0){
            popularList.innerHTML = temp.innerHTML;
            return;
        }

        perSlide = 0;
        bangunCarousel();
    }

    function bangunCarousel() {
        const carousel = document.getElementById("popular-carousel");
        const prev = document.getElementById("popular-prev");
        const next = document.getElementById("popular-next");
        if (!carousel || popularCards.length === 0) return;

        const tersedia = carousel.clientWidth - ROW_PADDING;
        const n = Math.min(MAX_PER_SLIDE, Math.max(1, Math.floor((tersedia + CARD_GAP) / (CARD_WIDTH + CARD_GAP))));

        if (n === perSlide) return;
        perSlide = n;

        const tampil = popularCards.slice(0, n * JUMLAH_SLIDE);

        if(popularList)popularList.innerHTML = "";

        for (let i = 0; i < tampil.length; i += n) {
            const item = document.createElement("div");
            item.className = "carousel-item" + (i === 0 ? " active" : "");

            const row = document.createElement("div");
            row.className = "popular-row";
            row.append(...tampil.slice(i, i + n));

            item.appendChild(row);
            if(popularList)popularList.appendChild(item);
        }

        const adaBanyakSlide = tampil.length > n;
        if(prev)prev.classList.toggle("d-none", !adaBanyakSlide);
        if(next)next.classList.toggle("d-none", !adaBanyakSlide);
    }

    if (popularList) {
        fetch("/api/resto")
        .then((response) => response.json())
        .then((restos) => {
            gabunganResto = gabungCabangResto(restos);

            renderExploreCarousel(restos);

            // index.html nampilin popular dishes
            if (popularList) renderPopular();
        })
        .catch((error) => console.error("Failed fetching /api/resto:", error));
    }
}