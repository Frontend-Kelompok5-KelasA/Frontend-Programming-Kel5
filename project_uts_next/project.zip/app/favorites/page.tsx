"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { onLoad } from "../../script/explore";
import FavoriteButton from "../../components/FavoriteButton";

export default function Favorites() {
    return (
        <main>
        <div className="main-container">

            <div className="list-resto">
                <h2>Your Favorite Resto</h2>
                <FavoriteButton />
                <div className="food-list d-flex flex-wrap justify-content-center gap-4" id="food-list">
                    {/* Card di-generate otomatis dari /api/resto lewat script.js */}
                </div>
            </div>
        </div>
        </main>
    );
}